document.getElementById('loginButton').addEventListener('click', function () {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const messageElement = document.getElementById('message');  // The element to display the message

    // API Gateway URL
    const apiUrl = 'https://oqtabfh9ti.execute-api.eu-west-1.amazonaws.com/dev/login';

    // Send POST request to the API Gateway
    fetch(apiUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
    })
    .then(response => {
        // Check if the response status is OK (200)
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        // Parse the response body (which is stringified JSON)
        const responseBody = JSON.parse(data.body);
        
        // Check the message in the response and update the page
        if (responseBody.message === "Success: Valid credentials!") {
            messageElement.style.color = "green";  // Success: Green color
        } else {
            messageElement.style.color = "red";  // Failure: Red color
        }
        messageElement.textContent = responseBody.message;  // Update the message text
    })
    .catch(error => {
        // Handle errors and display error message
        console.error('Error:', error);
        messageElement.style.color = "red";  // Error: Red color
        messageElement.textContent = "An error occurred. Please try again.";  // Error message
    });
});
